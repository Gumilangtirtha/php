
<?php

    $tanggal = 32;

    $hasil = $tanggal > 0;

    echo $hasil;

    // if ($tanggal < 32) {
    //     if ($tanggal > 0) {
    //         echo 'Benar';
    //     }else {
    //         echo 'salah';
    //     }
    // }else {
    //     echo 'Salah';
    // }

    $nilai = 100;

    // if ($nilai <= 100) {
    //     if ($nilai >= 0) {
    //         echo 'Nilai Benar';
    //     }else {
    //         echo 'Nilai Salah';
    //     }
    // }else {
    //     echo 'nilai salah';
    // }

    // if ($nilai >= 0 && $nilai <= 100) {
    //     echo 'Nilai Benar';
    // }else {
    //     echo 'Nilai Salah';
    // }

    if ($nilai >=100 || $nilai <=0 ) {
        echo 'Nilai Salah';
    }else {
        echo 'Nilai Benar';
    }

?>