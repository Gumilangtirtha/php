<?php

    $tulisan = 'Saya Belajar'.'<br>';

    echo $tulisan;

    $angka = '2019';

    echo 'Tahun '.$angka.'<br>';

    var_dump($tulisan);

    echo '<br>';

    var_dump((int)$angka+2);

?>