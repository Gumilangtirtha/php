<?php

    echo "Belajar PHP";

    echo '<br>';

    echo 'Saya Siswa SMK';

    echo '<h1 style="background-color:red">Belajar PHP itu Mudah</h1>
        <p style="background-color:blue"> Saya Suka belajar program </p>
    ';

    echo 'Saya Belajar'.' PHP'.'<br>';

    echo 2019 + 2;

?>