<h1>Registrasi Pelanggan</h1>
<div class="mb-3">
    <form action="" method="post">
        <div class="mb-3 w-50">

            <label for="">Pelanggan</label>
            <input type="text" name="pelanggan" required placeholder="isi pelanggan" class="form-control">

        </div>

        <div class="mb-3 w-50">

            <label for="">Alamat</label>
            <input type="text" name="alamat" required placeholder="isi alamat" class="form-control">

        </div>
        
        <div class="mb-3 w-50">

            <label for="">Telp</label>
            <input type="text" name="telp" required placeholder="isi telp" class="form-control">

        </div>

        <div class="mb-3 w-50">

            <label for="">Email</label>
            <input type="email" name="email" required placeholder="Email" class="form-control">

        </div>

        <div class="mb-3 w-50">

            <label for="">Password</label>
            <input type="password" name="password" required placeholder="password" class="form-control">

        </div>

        <div class="mb-3 w-50">

            <label for="">Konfirmasi Password</label>
            <input type="password" name="konfirmasi" required placeholder="password" class="form-control">

        </div>

        <div>

            <input type="submit" name="simpan"  value="simpan" class="btn btn-primary">

        </div>

    </form>

</div>

<?php

    if (isset($_POST['simpan'])) {
        $user = $_POST['pelanggan'];
        $user = $_POST['alamat'];
        $user = $_POST['telp'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $konfirmasi = $_POST['konfirmasi'];
        $level = $_POST['level'];

        if ($password === $konfirmasi ) {
            
            $sql = "INSERT INTO tblpelanggan VALUES ('','$pelanggan','$alamat','$telp','$user','$email','$password',1)";
            // echo $sql;
            $db->runSQL($sql);
            header("location:?f=user&m=select");
        }else {
            echo "<h3>PASSWORD TIDAK SAMA DENGAN KONFIRMASI</h3>";
        }
    }

?>