<h2>Registrasi Berhasil Silahkan Login</h2>
<div class="float-start me-4">
    <a class="btn btn-primary" href="?f=home&m=login" role="button">LOGIN</a>
</div>