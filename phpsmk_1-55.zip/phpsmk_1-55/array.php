<?php

    // array dimensi

    // $nama = array("joni", "tejo", "budi", "siti", 100, 2.5);

    // var_dump($nama);

    // echo "<br>";

    // echo $nama[5];

    // echo "<br>";

    // for ($i=0; $i < ; $i++) {
    //     // echo $i;
    //     echo $nama[$i]."<br>";
    // }

    // foreach ($nama as $k) {
    //     echo $k.'<br>';
    // }

    // array assosiatif

    // $nama = array(
    //     "joni" => "surabaya",
    //     "budi" => "malang raya",
    //     "tejo" => "jakarta",
    //     "siti" => "sidoarjo"
    // );

    $nama["joni"]="surabaya";
    $nama["budi"]="malang raya";
    $nama["tejo"]="jakarta";
    $nama["siti"]="sidoarjo";
    $nama["edi"]="semarang";

    var_dump($nama);

    echo "<br>";

    // echo $nama['budi'];

    foreach ($nama as $key => $v) {
        echo $key." =>".$v;

        echo "<br>";
    }

?>