<?php

    //OPERATOR MATEMATIKA

    $a = 5;
    $b = 2;

    $c = $a + $b;
    echo $c.'<br>';

    $c = $a - $b;
    echo $c.'<br>';

    $c = $a * $b;
    echo $c.'<br>';

    $c = $a / $b;
    echo floor($c).'<br>';

    $c = $a % $b;
    echo $c.'<BR>';

    //  OPERATOR LOGIKA

    $c = $a < $b;
    echo $c;

    $c = $a > $b;
    echo $c;

    $c = $a == $b;
    echo $c;

    $c = $a != $b;
    echo $c.'<br>';

    //  INCREMENT
    $a++;
    echo $a.'<br>';

    // OPERATOR STRING

    $kata = 'Sura';
    $kota = 'Baya';

    $hasil = $kata.$kota;

    $hasil .=' KOTA PAHLAWAN';
    echo $hasil;

?>